<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>

    <div class="panel panel-info">

      <div class="panel-body" style="background-color:pink; height:600px;width:100%;">
            <h4><b>Menu WebGIS</b></h4>
            <div class="row">

              <div class="col-sm-4">

                <select>
                      <option value=""> Rumah</option>
                      <option value=""> Jalan</option>
                      <option value=""> Irigasi</option>
                </select>
              </div>

              <div class="col-sm-8">
                 <input type="checkbox" name="Koto Gadang" value="Koto Gadang"> Koto Gadang
                 <input type="checkbox" name="Gantiang" value="Gantiang"> Gantiang
                 <input type="checkbox" name="Sutijo" value="Sutijo"> Sutijo

              </div>

            </div>

            <br/><b> Filter Rumah </b>
            <select>
                  <option value=""> Rumah</option>
                  <option value=""> Rumah Kosong </option>
                  <option value=""> Rumah Berpenghuni</option>
            </select>

            <br/><b> Filter Pendapatan </b>

            <select>
                  <option value=""> Kategori Satu</option>
                  <option value=""> Kategori Dua </option>
                  <option value=""> Kategori Tiga</option>
            </select>

            <div class="panel panel-info">

               <div class="panel-head" style="background-color:grey;">
                 <b>Pencarian</b>
               </div>

               <div class="panel-body">

                 <input type="text" name="" value="">
                 <button type="button" class="btn btn-info" name="button">Cari KK</button>
                 <i style="background-color:green; color:white;">Ditemukan/Tidak Ditemukan</i>

               </div>

            </div>

          <div class="panel panel-info">


          </div>

      </div>

    </div>

  </body>
</html>
