<html>

<head>

</head>

<body>



    <div class="panel panel-info">

         <div class="panel-body" style="background-color:black; width:100%;height:50px;">
            <div class="container">

            </div>
         </div>
    </div>



</body>

</html>
