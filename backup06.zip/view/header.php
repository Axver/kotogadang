<html>

<head>

</head>

<body>



    <div class="panel panel-info">

         <div class="panel-body" style="background-color:black; width:100%;height:100px;">
           <div class="row">

             <div class="col-sm-4">
               <h1 style="color:white;"><i>KOTOGADANG<i></h1>
             </div>

             <div class="col-sm-4">

             </div>

             <div class="col-sm-4">

             </div>

           </div>
            <div class="container">

            </div>
         </div>
    </div>



</body>

</html>
